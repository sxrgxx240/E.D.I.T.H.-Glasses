package com.edith.glasses.audio

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager

/** Which microphone voice sessions capture from. */
enum class MicSource(val label: String, val description: String) {
    GLASSES(
        "Lentes / Bluetooth",
        "Usa el micrófono de los lentes cuando estén conectados como audífonos Bluetooth."
    ),
    PHONE(
        "Teléfono",
        "Usa el micrófono integrado del celular. La respuesta sigue saliendo por la bocina de los lentes."
    ),
    EXTERNAL(
        "Externo (USB)",
        "Usa un micrófono USB conectado al teléfono. Si no hay ninguno, regresa al del celular."
    );

    companion object {
        fun fromName(name: String?): MicSource =
            entries.firstOrNull { it.name == name } ?: GLASSES
    }
}

private const val PREFS_FILE = "edith_glasses_prefs"

private fun prefs(context: Context) =
    context.applicationContext.getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)

object MicPrefs {
    fun get(context: Context): MicSource =
        MicSource.fromName(prefs(context).getString("mic_source", null))

    fun set(context: Context, source: MicSource) {
        prefs(context).edit().putString("mic_source", source.name).apply()
    }
}

object CameraPrefs {
    /** Photo quality 0..5: Instant, Quick, Smooth, Fine, Clearer, Detailed. */
    fun photoQuality(context: Context): Int =
        prefs(context).getInt("camera_photo_quality", 4).coerceIn(0, 5)

    fun setPhotoQuality(context: Context, quality: Int) {
        prefs(context).edit().putInt("camera_photo_quality", quality.coerceIn(0, 5)).apply()
    }

    /** Video recording duration in seconds. */
    fun videoDuration(context: Context): Int =
        prefs(context).getInt("camera_video_duration", 60)

    fun setVideoDuration(context: Context, seconds: Int) {
        prefs(context).edit().putInt("camera_video_duration", seconds).apply()
    }
}

object AutoDownloadPrefs {
    fun enabled(context: Context): Boolean =
        prefs(context).getBoolean("auto_download_after_video", false)

    fun set(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean("auto_download_after_video", enabled).apply()
    }
}

object ApiKeyPrefs {
    fun get(context: Context): String =
        prefs(context).getString("gemini_api_key", "") ?: ""

    fun set(context: Context, key: String) {
        prefs(context).edit().putString("gemini_api_key", key.trim()).apply()
    }
}

/** Resolves the input [AudioDeviceInfo] to force for a [MicSource]; null = system default. */
object MicDeviceResolver {
    fun resolve(context: Context, source: MicSource): AudioDeviceInfo? {
        if (source == MicSource.GLASSES) return null
        val audioManager = context.applicationContext
            .getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val inputs = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
        return when (source) {
            MicSource.PHONE -> inputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
            MicSource.EXTERNAL -> inputs.firstOrNull {
                it.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
                    it.type == AudioDeviceInfo.TYPE_USB_ACCESSORY ||
                    it.type == AudioDeviceInfo.TYPE_USB_HEADSET
            }
            MicSource.GLASSES -> null
        }
    }
}
